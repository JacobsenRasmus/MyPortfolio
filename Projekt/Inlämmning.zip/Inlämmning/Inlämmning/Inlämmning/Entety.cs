﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Inlämmning
{
    public abstract class Entety
    {
        // huvud class som jag inisierar saker i 

        public Texture2D texture; // tillåter sub-classeran att ha bilder
        public Texture2D BullTex;

        public Vector2 pos; // sub- classens position
        public Vector2 speed; // sub-classens hastighet
        public Vector2 origo; // låter oss hita obijektest mittbunkt

        public Color[] textureData;
        public Color[] enemyData;

        public Rectangle rec;
        public Rectangle EnemyRec; 

        public bool Bool = false;

        public GameWindow Window;   // gör så att Window.ClientBounds.* funkar 
                                    //vet inte varför det inte gör det utan den

        public SpriteBatch spriteBatch;
        public Random slump = new Random();
    }
}
