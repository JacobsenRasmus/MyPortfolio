﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace Inlämmning
{
    class PlayerBullet : Entety
    {
        public PlayerBullet(Texture2D newtexture)
        {
            texture = newtexture;
            textureData = new Color[texture.Width * texture.Height];
            texture.GetData(textureData);
            rec = new Rectangle(Convert.ToInt32(pos.X), Convert.ToInt32(pos.Y), texture.Width, texture.Height);

            Bool = false;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, pos, Color.White);
        }
    }
}
