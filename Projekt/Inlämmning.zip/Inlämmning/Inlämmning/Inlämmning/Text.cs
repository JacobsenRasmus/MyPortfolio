﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Inlämmning
{
    class Text
    {
        SpriteFont gamefont;

        public Text(SpriteFont text)
        {
            gamefont = text;
        }
        public void DrawMain(SpriteBatch spriteBatch, GameWindow graphics)
        {
            spriteBatch.DrawString(gamefont, "Begin (Enter)", 
                new Vector2((graphics.ClientBounds.Width/2) + (graphics.ClientBounds.Width / 10), 
                (graphics.ClientBounds.Height/2) - 50), Color.White);

            spriteBatch.DrawString(gamefont, "Exit (Esc)",
                new Vector2((graphics.ClientBounds.Width / 2) + (graphics.ClientBounds.Width / 10),
                (graphics.ClientBounds.Height / 2) + 50), Color.White);
        }

        public void DrawGame(SpriteBatch spriteBatch, Player spelare)
        {
            spriteBatch.DrawString(gamefont, "Score: " + spelare.score,
                new Vector2(10, 10), Color.White);

            spriteBatch.DrawString(gamefont, "Liv: " + spelare.HP,
                new Vector2(10, 35), Color.White);
        }
    }
}
