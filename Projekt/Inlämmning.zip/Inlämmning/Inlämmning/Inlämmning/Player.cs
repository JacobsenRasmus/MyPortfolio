﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Inlämmning
{
    class Player : Entety
    {
        List<PlayerBullet> bullets = new List<PlayerBullet>();
        public int HP = 5, score = 0;

        public Player(Texture2D newTexture, GameWindow window, Texture2D newBullTex)
        {
            texture = newTexture;
            textureData = new Color[texture.Width * texture.Height];
            texture.GetData(textureData);

            BullTex = newBullTex;
            pos = new Vector2(window.ClientBounds.Width / 2, texture.Height);

            speed.X = 3.5f;
            speed.Y = 3.5f;
        }

        float avfyra = 0;
        public void Update(GameWindow graphics, GameTime gameTime, List<EnemyOne>Grunt)
        {
            KeyboardState keyboardState = Keyboard.GetState();
            // tillåter spelet att se vilka tangenter det är du trycker ner

            if (keyboardState.IsKeyDown(Keys.Right) || keyboardState.IsKeyDown(Keys.D)) // moves player to the right 
            {
                if (pos.X < (graphics.ClientBounds.Width - texture.Width))
                    pos.X = pos.X + speed.X;
            }
            if (keyboardState.IsKeyDown(Keys.Left) || keyboardState.IsKeyDown(Keys.A)) // moves player to the left
            {
                if (pos.X > 0)
                    pos.X = pos.X - speed.X;
            }

            if (keyboardState.IsKeyDown(Keys.Up) || keyboardState.IsKeyDown(Keys.W)) // Move player up
            {
                if (pos.Y > 0)
                    pos.Y = pos.Y - speed.Y;
            }
            if (keyboardState.IsKeyDown(Keys.Down) || keyboardState.IsKeyDown(Keys.S)) // move player down
            {
                if (pos.Y < (graphics.ClientBounds.Height - texture.Height))
                    pos.Y = pos.Y + speed.Y;
            }

            avfyra += (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (keyboardState.IsKeyDown(Keys.Space))
            {
                if (avfyra > 0.5)
                {
                    avfyra = 0;
                    Shoot();
                }
            }

            UpdateBullet(Grunt);
            // skapar en rektangel runt spelaren
            rec = new Rectangle(Convert.ToInt32(pos.X), Convert.ToInt32(pos.Y), texture.Width, texture.Height);
        }

        public void UpdateBullet(List<EnemyOne>Grunt)
        {
            foreach(PlayerBullet bull in bullets)
            {
                bull.pos += bull.speed;
                if (bull.pos.Y < 0)
                    bull.Bool = false;
                bull.rec = new Rectangle(Convert.ToInt32(pos.X), Convert.ToInt32(pos.Y), texture.Width, texture.Height);
            }
            /*
            foreach(PlayerBullet bull in bullets)
            {
                foreach(EnemyOne grunt in Grunt)
                {
                    if (Collition.Boom(bull.rec, bull.textureData, grunt.rec, grunt.textureData))
                    {
                        
                    }
                }
            }
            */
            foreach(PlayerBullet bull in bullets)
            {
                for (int i = 0; i < Grunt.Count; i++)
                {
                    if(Collition.Boom(bull.rec, bull.textureData, Grunt[i].rec, Grunt[i].textureData))
                    {
                        Grunt.RemoveAt(i);
                        i--;
                    }
                }

            }
            for (int i = 0; i < bullets.Count; i++)
            {
                /*
                for (int e = 0; e < Grunt.Count; e++)
                {
                    if (Collition.Boom(bullets[i].rec, bullets[i].textureData, Grunt[e].rec, Grunt[e].textureData))
                    {
                        bullets.RemoveAt(i);
                        Grunt.RemoveAt(e);
                        score += 100;
                        e--;
                        i--;
                    }
                    else if (!bullets[i].Bool)
                    {
                        bullets.RemoveAt(i);
                        i--;
                    }
                }*/
                if (!bullets[i].Bool)
                {
                    bullets.RemoveAt(i);
                    i--;
                }
            }
        }

            int u = 0;
        public void Shoot()
        {
            PlayerBullet newBullet = new PlayerBullet(BullTex);
            newBullet.speed = new Vector2(0f, -3f);
            switch (u)
            {
                case 0:
                    newBullet.pos = new Vector2(pos.X + 1, pos.Y);
                    u = 1;
                    break;
                case 1:
                    newBullet.pos = new Vector2(pos.X + texture.Width - 6, pos.Y);
                    u = 0;
                    break;
            }
            newBullet.Bool = true;

            bullets.Add(newBullet);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (PlayerBullet bull in bullets)
                bull.Draw(spriteBatch);
            spriteBatch.Draw(texture, pos, Color.White);
        }

    }
}