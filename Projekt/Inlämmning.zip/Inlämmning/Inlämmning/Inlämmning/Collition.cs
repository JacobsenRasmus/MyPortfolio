﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Inlämmning
{
    class Collition
    {
        public static bool Boom(Rectangle rec1, Color[] data1, Rectangle rec2, Color[] data2)
        {
            int top = Math.Max(rec1.Top, rec2.Top);
            int bot = Math.Min(rec1.Bottom, rec2.Bottom);
            int left = Math.Max(rec1.Left, rec2.Left);
            int right = Math.Min(rec1.Right, rec2.Right);

            for (int y = top; y < bot; y++)
            {
                for (int x = left; x < right; x++)
                {
                    Color color1 = data1[(x - rec1.Left) + (y - rec1.Top) * rec1.Width];
                    Color color2 = data2[(x - rec2.Left) + (y - rec2.Top) * rec2.Width];

                    if (color1.A != 0 && color2.A != 0)
                        return true;
                }
            }
            return false;
        }
    }
}
