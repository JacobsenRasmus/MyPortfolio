﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Inlämmning
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Text font;

        enum GameState
        {
            MainMenu,
            Playing,
            Dead, 
        }
        GameState CurrentState = GameState./*Playing/*/MainMenu;

        // Things
        Player Spelare;

        List<EnemyOne> Grunt = new List<EnemyOne>();
        List<EnemyTwo> Trunt = new List<EnemyTwo>();

        Random slump = new Random();

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            //graphics.IsFullScreen = true;
            Content.RootDirectory = "Content";
        }
        
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            base.Initialize();
        }
        
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            Spelare = new Player(Content.Load<Texture2D>("Sprites/ship"),
                Window, Content.Load<Texture2D>("Sprites/bullet"));
            font = new Text(Content.Load<SpriteFont>("Text/SpriteFont1"));
        }
        
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        float spawnOne = 0, spawnTwo = 0;
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            KeyboardState keyboardState = Keyboard.GetState();
            switch (CurrentState)
            {
                case GameState.MainMenu:

                    if (keyboardState.IsKeyDown(Keys.Escape))
                        this.Exit();
                    if (keyboardState.IsKeyDown(Keys.Enter))
                        CurrentState = GameState.Playing;

                    break;

                case GameState.Playing:

                    spawnOne += (float)gameTime.ElapsedGameTime.TotalSeconds;
                    spawnTwo += (float)gameTime.ElapsedGameTime.TotalSeconds;

                    Spelare.Update(Window, gameTime, Grunt);
                    
                    foreach (EnemyOne enemy in Grunt)
                        enemy.Update(Window, Spelare);

                    foreach (EnemyTwo enemy in Trunt)
                        enemy.Update(Window, Spelare, gameTime);

                    loadEnemyOne();
                    loadEnemyTwo();

                    break;

                case GameState.Dead:
                    break;
            }


            base.Update(gameTime);
        }

        public void loadEnemyOne()
        {
            int posY, posX;
            posX = slump.Next(0, (Window.ClientBounds.Width - 78));
            posY = slump.Next(-300, 0);

            if (spawnOne >= 1)
            {
                spawnOne = 0;
                Grunt.Add(new EnemyOne(Content.Load<Texture2D>("Sprites/tripod"), new Vector2(posX, posY)));
            }

            for(int i = 0; i < Grunt.Count; i++)
            {

                if (Collition.Boom(Grunt[i].rec, Grunt[i].textureData, Spelare.rec, Spelare.textureData))
                {
                    Grunt.RemoveAt(i);
                    Spelare.HP -= 1;
                    i--;
                }
                else if (!Grunt[i].syns)
                {
                    Grunt.RemoveAt(i);
                    i--;
                }
            }
        }

        public void loadEnemyTwo()
        {
            int posY, posX;
            posX = slump.Next(0, (Window.ClientBounds.Width - 78));
            posY = slump.Next(-100, 0);

            if (spawnTwo >= 5)
            {
                spawnTwo = 0;
                Trunt.Add(new EnemyTwo(Content.Load<Texture2D>("Sprites/coin"),
                    new Vector2(posX, posY), Content.Load<Texture2D>("Sprites/bullet")));
            }
            for(int i = 0; i < Trunt.Count; i++)
            {
                if (Collition.Boom(Trunt[i].rec, Trunt[i].textureData, Spelare.rec, Spelare.textureData))
                {
                    Trunt.RemoveAt(i);
                    i--;
                    Spelare.HP -= 1;
                }

            }
        }

        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            switch (CurrentState)
            {
                case GameState.MainMenu:

                    GraphicsDevice.Clear(Color.CornflowerBlue);
                    spriteBatch.Begin();
                    font.DrawMain(spriteBatch, Window);
                    spriteBatch.End();

                    break;
                case GameState.Playing:

                    GraphicsDevice.Clear(Color.CornflowerBlue);

                    spriteBatch.Begin();

                    Spelare.Draw(spriteBatch);

                    foreach (EnemyOne enOne in Grunt)
                        enOne.Draw(spriteBatch);

                    foreach (EnemyTwo enTwo in Trunt)
                        enTwo.Draw(spriteBatch);

                    font.DrawGame(spriteBatch, Spelare);

                    spriteBatch.End();

                    break;
                case GameState.Dead:
                    break;
            }
            base.Draw(gameTime);
        }
    }
}
