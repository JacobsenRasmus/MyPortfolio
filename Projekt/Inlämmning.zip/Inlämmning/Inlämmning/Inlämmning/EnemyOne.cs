﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Inlämmning
{
    class EnemyOne : Entety
    {
        public bool syns = true;
        private int bred;

        public EnemyOne(Texture2D newTexture, Vector2 newPos)
        {
            texture = newTexture;
            textureData = new Color[texture.Width * texture.Height];
            texture.GetData(textureData);

            pos = newPos;

            speed.X = 0;
            speed.Y = slump.Next(2, 5);
            speed = new Vector2(speed.X, speed.Y);

            bred = texture.Width;
        }

        public void Update(GameWindow graphics, Player player)
        {
            pos += speed;

            if (pos.Y > graphics.ClientBounds.Height)
                syns = false;

            rec = new Rectangle(Convert.ToInt32(pos.X), Convert.ToInt32(pos.Y), texture.Width, texture.Height);

        }
        
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, pos, Color.White);
        }

    }
}
